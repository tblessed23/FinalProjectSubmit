package com.example.android.cornyjokes;

public class CornyJokes {

    public String getCornyJokes(){
     return "Do you like eggs? Egg no Java.";
    }
}